import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { Observable } from 'rxjs/Observable';
import { Address } from '../../Models/addressModel';
import { Coordinates } from '../../Models/coordinatesModel'



const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class DistanceService {

  constructor(private http: HttpClient) { }

  getDistance(userId: string, cardId: string)
  {

    var userCoordinates = this.getCoordinates(this.getUserAddress(userId));
    var cardCoordinates = this.getCoordinates(this.getCardAddress(cardId));

    //calculateDistance(userCoordinates, cardCoordinates);

  }

  getUserAddress(userId: string) : Address
  {
    var address = new Address();
    address.address = "1910+8th+St";
    address.city = "Brookings";
    address.state = "SD";

    return address;
  }

  getCardAddress(cardId: string) : Address
  {
    var address = new Address();
    address.address = "902+Onaka+Trail";
    address.city = "Brookings";
    address.state = "SD";

    address.address = address.address.replace(' ', '+');
    address.city = address.city.replace(' ', '+');
    address.state = address.state.replace(' ', '+');

    return address;
  }

  getCoordinates(address: Address)
  {
    var t;
    //console.log(`https://maps.googleapis.com/maps/api/geocode/json?address=${address.address},+${address.city},+${address.state}&key=AIzaSyAB_YxBwJDx789R40HHZ7sner5sjOdDK7A`);
    this.http.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${address.address},+${address.city},+${address.state}&key=AIzaSyAB_YxBwJDx789R40HHZ7sner5sjOdDK7A`).subscribe(data => t = JSON.parse(data.toString()));
    console.log(t.geometry.location.lat);
  }

  // calculateDistance(userCoordinates: Coordinates, cardCoordinates: Coordinates) : number
  // {

  // }

}
