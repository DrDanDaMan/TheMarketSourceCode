import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Card } from 'src/Models/cardModel';
import { ProductList } from 'src/Models/productList';
import { User } from '../_models';
import { FilterServiceService } from './filter-service.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
const url = 'https://localhost:44317/api/GetCards?';

@Injectable({
  providedIn: 'root'
})

export class StoreService {

  constructor(private httpClient: HttpClient, private filterService: FilterServiceService) { }
  user: User = null;
  public products: Card[];

  getAllCards(): Observable<Card[]>{
    this.user = JSON.parse(localStorage.getItem('user'));
    const tempURL = url.concat('userId='+ this.user.userId + '&filters=Distance:' + this.filterService.distance);
    return this.httpClient.get<Card[]>(tempURL);
  }

  getAllRecommendedCards(): Observable<Card[]>{
    this.user = JSON.parse(localStorage.getItem('user'));
    const tempURL = 'https://localhost:44317/api/GetRecommendedCards?' + 'userId=' + this.user.userId;
    return this.httpClient.get<Card[]>(tempURL);
  }

  getAllSuggestedCards(): Observable<Card[]>{
    this.user = JSON.parse(localStorage.getItem('user'));
    const tempURL = 'https://localhost:44317/api/GetSuggestedCards?' + 'userId=' + this.user.userId;
    return this.httpClient.get<Card[]>(tempURL);
  }

  getFilteredCards(search: string): Observable<Card[]>{
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log(search);
    let tempURL = '';
    if (search !== '') {
      tempURL = url.concat('userId=' + this.user.userId + '&filters=' + this.filterService.getFilters() + 'Search:' + search);
    }
    else {
      tempURL = url.concat('userId=' + this.user.userId + '&filters=' + this.filterService.getFilters());
    }

    const cards = this.httpClient.get<Card[]>(tempURL);
    return cards;
  }

  getCart(): Observable<Card[]>
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    return this.httpClient.get<Card[]>('https://localhost:44317/api/GetCart?userId=' + this.user.userId);
  }

  AddToCart(id: number): boolean
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log(this.user);
    console.log(id);
    var result = false;
    this.httpClient.get<boolean>('https://localhost:44317/api/AddToCarts?userID=' + this.user.userId + '&cardIds=' + id)
      .subscribe(arg => result = arg);
    return result;
  }

  RemoveFromCart(id: number): boolean
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log("hit");
    var result = false;
    this.httpClient.get<boolean>('https://localhost:44317/api/RemoveCardsFromCart?userID=' + this.user.userId + '&cardIds=' + id)
      .subscribe(arg => result = arg);
    return result;
  }

  ClearCart()
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log(this.user.userId);
    console.log(this.httpClient.get('https://localhost:44317/api/ClearCart?userID=' + this.user.userId).subscribe());
  }

  DeleteCard(id: number)
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log('hello');
    console.log(this.httpClient.get('https://localhost:44317/api/DeleteCards?cardIds=' + id).subscribe());
  }

  GetMyCards()
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    return this.httpClient.get<Card[]>('https://localhost:44317/api/GetMyCards?userID=' + this.user.userId);
  }

  UploadFile(fileToUpload: File, id: number)
  {
    const endpoint = 'https://localhost:44317/api/UploadImage';
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('ProductId', id.toString());
    return this.httpClient
      .post('https://localhost:44317/api/UploadImage?productId=' + id.toString(), formData).subscribe();
  }

  UploadCard(title: string, price: string, description: string, category: string, files: Array<File>)
  {
    if(this.user === null)
      this.user = JSON.parse(localStorage.getItem('user'));
    console.log(this.user);
    var productId = 0;
    var filecount = 0;
    if(files != null)
      filecount = files.length;

    var url = 'https://localhost:44317/api/InsertCard?categories=' + category + '&' +
    'productName=' + title + '&' + 'userId=' + this.user.userId + '&' + 'cost=' + price + '&' + 'description=' + description + '&' + 'images=' + filecount;

    console.log(url);
    this.httpClient.get<number>(url)
      .subscribe( args => {
        productId = args;
        console.log(args, 'hit');
        if (files != null)
        {
          for(let num = 0; num < files.length; num++)
          {
            this.UploadFile(files[num], args);
          }
        }
      });
  }

  PurchaseItem(id: number)
  {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log("hit");
    var result = false;
    this.httpClient.get<boolean>('https://localhost:44317/api/Purchase?userID=' + this.user.userId + '&productId=' + id)
      .subscribe(arg => result = arg);
    return result;
  }

}
