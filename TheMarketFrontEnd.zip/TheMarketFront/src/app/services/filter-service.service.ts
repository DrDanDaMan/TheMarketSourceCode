import { Injectable } from '@angular/core';
import { StoreService } from './store.service';

@Injectable({
  providedIn: 'root'
})
export class FilterServiceService {

  constructor() { }
  public categories: Array<string>;
  public distance = 50;
  public minPrice: number;
  public maxPrice: number;
  private filters = '';

  getFilters() : string
  {
    if (this.distance != null)
    {
      this.filters = this.filters.concat('Distance:' + this.distance.toString() + ';');
    }
    if (this.minPrice != null && this.maxPrice != null)
    {
      this.filters = this.filters.concat('Price:' + this.minPrice.toString() + '-' + this.maxPrice.toString() + ';');
    }
    if (this.categories != null && this.categories.length !== 0)
    {
      console.log('hit');
      this.filters = this.filters.concat('Categories:');

      this.categories.forEach(element => {
        this.filters = this.filters.concat(element + ',');
      });

      this.filters = this.filters.concat(';');
    }

    console.log(this.filters);
    var temp = this.filters;
    this.filters = '';
    return temp;
  }


}
