import { Component, NgModule} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, FormControl, ValidatorFn, FormsModule} from '@angular/forms';
import { MatSliderChange } from '@angular/material/slider';
import { filter } from 'rxjs/operators';
import { FilterServiceService } from '../services/filter-service.service';
import { StoreService } from '../services/store.service';

const Categories = [
  {id: 1, name: 'Electronics'},
  {id: 2, name: 'Sports'},
  {id: 3, name: 'Appliances'},
  {id: 4, name: 'Vehicles'},
  {id: 5, name: 'Home'},
  {id: 6, name: 'Clothing'},
  {id: 7, name: 'Entertainment'},
  {id: 8, name: 'Beauty'},
  {id: 9, name: 'Outdoors'},
];

@Component({
  selector: 'app-filter-bar',
  templateUrl: './filter-bar.component.html',
  styleUrls: ['./filter-bar.component.css']
})

export class FilterBarComponent{
  minPrice: number;
  maxPrice: number;
  distance = '50';

  form: FormGroup;
  catData = [
    {id: 1, name: 'Electronics'},
    {id: 2, name: 'Sports'},
    {id: 3, name: 'Appliances'},
    {id: 4, name: 'Vehicles'},
    {id: 5, name: 'Home'},
    {id: 6, name: 'Clothing'},
    {id: 7, name: 'Entertainment'},
    {id: 8, name: 'Beauty'},
    {id: 9, name: 'Outdoors'},
  ];

  get catFormArray(){
    return this.form.controls.cat as FormArray;
  }

  constructor(private formBuilder: FormBuilder, private filterService: FilterServiceService, private storeService: StoreService){
    this.form = this.formBuilder.group({cat: new FormArray([])});

    this.addCheckboxes();
  }

  private addCheckboxes(){
    this.catData.forEach(() => this.catFormArray.push(new FormControl(false)));
  }

  submit()
  {
    const selectedCatIds = this.form.value.cat
    .map((checked, i) => checked ? this.catData[i].name : null)
    .filter(v => v !== null);

    this.filterService.categories = selectedCatIds;
    //this.storeService.update();
  }

  distanceChange(event: MatSliderChange)
  {
    this.filterService.distance = event.value;
    //this.storeService.update();
  }

  minPriceChanged()
  {
    this.filterService.minPrice = this.minPrice;
    //this.storeService.update();
  }

  maxPriceChanged()
  {
    this.filterService.maxPrice = this.maxPrice;
    //this.storeService.update();
  }
  formatLabel(value: number) {
    return value;
  }

}

