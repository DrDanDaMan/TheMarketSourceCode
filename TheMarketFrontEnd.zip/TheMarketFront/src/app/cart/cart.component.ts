import { Component, OnInit } from '@angular/core';
import { Card } from 'src/Models/cardModel';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cards: Array<Card>;
  constructor(public storeService: StoreService) { }

  ngOnInit(): void {
    this.storeService.getCart()
    .pipe().subscribe(arg => this.cards = arg);
    console.log("hit");
    console.log(this.cards);
    console.log("hit");
  }

  RemoveCard(card: Card)
  {
    console.log(card);
    const index: number = this.cards.indexOf(card);
    if (index !== -1) {
      this.cards.splice(index, 1);
    }
    console.log("Card Removed");
  }

  ClearCart()
  {
    this.storeService.ClearCart();
    this.cards = new Array<Card>();
  }
}
