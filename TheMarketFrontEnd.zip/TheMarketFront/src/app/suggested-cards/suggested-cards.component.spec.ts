import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuggestedCardsComponent } from './suggested-cards.component';

describe('SuggestedCardsComponent', () => {
  let component: SuggestedCardsComponent;
  let fixture: ComponentFixture<SuggestedCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuggestedCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuggestedCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
