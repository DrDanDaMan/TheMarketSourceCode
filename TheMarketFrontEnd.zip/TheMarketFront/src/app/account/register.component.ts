﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';

import { first } from 'rxjs/operators';
import { INTERESTS } from '../../Models/mock-interests';
import { AccountService, AlertService } from '../_services';
import { Interest } from 'src/Models/interestsModel';
import { Title } from '@angular/platform-browser';

@Component({
   templateUrl: 'register.component.html',
   styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    loading = false;
    submitted = false;
    public UserFormGroup: FormGroup;
    isLinear = false;
    hide = true;
    interests = INTERESTS;
    electronics = false;
    sports = false;
    appliances = false;
    vehicles = false;
    home = false;
    clothing = false;
    entertainment = false;
    health = false;
    outdoors = false;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService
    ) { }

    ngOnInit() {

      const formArray = this.formBuilder.array([]);
      console.log(this.interests);
      for (const interest of this.interests) {
        formArray.push(
          this.formBuilder.group({name: new FormControl(interest.title)})
        );
      }

      this.UserFormGroup = this.formBuilder.group({

        username: ['', Validators.required],
        password: ['', [Validators.required, Validators.minLength(6)]],
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        phoneNumber: ['', [Validators.required, Validators.pattern("[0-9 ]{11}")]],
        address: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zipcode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
        interestArray: this.formBuilder.array([]),
        electronics: [],
        sports: [],
        appliances: [],
        vehicles: [],
        home: [],
        clothing: [],
        entertainment: [],
        beauty: [],
        outdoors: [],

      });
  }

  get fromInterests() {
    return <FormArray>this.UserFormGroup.get('interests'); }

    // convenience getter for easy access to form fields
    get f() { return this.UserFormGroup.controls; }

    onSubmit() {
        this.submitted = true;
        console.log(this.UserFormGroup.value);
        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.UserFormGroup.invalid) {
            return;
        }

        this.loading = true;
        this.accountService.register(this.UserFormGroup.value, this.electronics,
          this.sports, this.appliances, this.vehicles,
          this.home, this.clothing, this.health,
          this.entertainment, this.outdoors)
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('Registration successful', { keepAfterRouteChange: true });
                    this.router.navigate(['../login'], { relativeTo: this.route });
                },
                error: error => {
                    this.alertService.error(error);
                    this.loading = false;
                }
            });
    }

    onCheckboxChange(e) {
      const checkArray: FormArray = this.UserFormGroup.get('interestArray') as FormArray;

      console.log(e.target.value);
      console.log(e.target.name);
      var i = new Interest();
      i.title = e.target.name;
      i.value = e.target.value;
      if (e.target.checked) {
        checkArray.push(new FormControl(i));
      } else {
        let i: number = 0;
        checkArray.controls.forEach((item: FormControl) => {
          if (item.value == e.target.value) {
            checkArray.removeAt(i);
            return;
          }
          i++;
        });
      }
    }

    onElectronicsChanged(status: boolean)
    {
      this.electronics = status;
    }

    onSportsChanged(status: boolean)
    {
      this.sports = status;
    }

    onAppliancesChanged(status: boolean)
    {
      this.appliances = status;
    }

    onVehiclesChanged(status: boolean)
    {
      this.vehicles = status;
    }

    onHomeChanged(status: boolean)
    {
      this.home = status;
    }

    onClothingChanged(status: boolean)
    {
      this.clothing = status;
    }

    onEntertainmentChanged(status: boolean)
    {
      this.entertainment = status;
    }

    onHealthChanged(status: boolean)
    {
      this.health = status;
    }

    onOutdoorsChanged(status: boolean)
    {
      this.outdoors = status;
    }
  }
