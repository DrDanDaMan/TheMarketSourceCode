﻿import { Component } from '@angular/core';

import { AccountService } from './_services';
import { User } from './_models';
import { fromEventPattern } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    user: User;
    firstName: string = '';
    constructor(private accountService: AccountService, private router: Router) {
        this.accountService.user.subscribe(x => {this.user = x; console.log('hit'); if(x!=null)this.firstName = x.firstName});
    }

    logout() {
        this.accountService.logout();
    }

    TitleClick()
    {
      this.router.navigateByUrl('/store');
    }

    CartClick()
    {
      this.router.navigateByUrl('/cart');
    }

    OpenMyCards()
    {
      this.router.navigateByUrl('/myCards');
    }

    OpenAddCard()
    {
      this.router.navigateByUrl('/addCard');
    }
}
