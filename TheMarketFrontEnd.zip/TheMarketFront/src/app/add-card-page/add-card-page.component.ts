import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-add-card-page',
  templateUrl: './add-card-page.component.html',
  styleUrls: ['./add-card-page.component.css']
})
export class AddCardPageComponent implements OnInit {
  public CardFormGroup: FormGroup;

  constructor(public storeService: StoreService, private formBuilder: FormBuilder, public router: Router) { }
  ngOnInit() {

    // const formArray = this.formBuilder.array([]);
    // console.log(this.interests);
    // for (const interest of this.interests) {
    //   formArray.push(
    //     this.formBuilder.group({name: new FormControl(interest.title)})
    //   );
    // }

    // this.CardFormGroup = this.formBuilder.group({

    //   username: ['', Validators.required],
    //   password: ['', [Validators.required, Validators.minLength(6)]],
    //   firstName: ['', Validators.required],
    //   lastName: ['', Validators.required],
    //   email: ['', [Validators.required, Validators.email]],
    //   phoneNumber: ['', [Validators.required, Validators.pattern("[0-9 ]{11}")]],
    //   address: ['', Validators.required],
    //   city: ['', Validators.required],
    //   state: ['', Validators.required],
    //   zipcode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
    //   interestArray: this.formBuilder.array([]),
    // });
}

  title: string;
  price: string;
  description: string;
  category: string;
  filesToUpload: Array<File> = new Array<File>();

  handleFileInput(files: FileList) {

    for (let index = 0; index < files.length; index++) {
        this.filesToUpload[this.filesToUpload.length] = files.item(index);
    }

    console.log(this.filesToUpload);

  }

  createCard()
  {
    console.log(this.category);
    this.storeService.UploadCard(this.title, this.price, this.description, this.category, this.filesToUpload);
    this.filesToUpload = new Array<File>();
    this.router.navigateByUrl('store');
  }
}
