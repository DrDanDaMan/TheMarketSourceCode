import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { MatCarousel, MatCarouselComponent } from '@ngbmodule/material-carousel';
import { from } from 'rxjs';
import { DistanceService } from '../services/distance.service';
import { Card } from '../../Models/cardModel';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})



export class CardComponent implements OnInit {
  // slides = [{'image': '../../assets/Images/rollerBlades.jpg'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'}];

  temps: string[];

  @Input() card: Card;
  @Output() Added: EventEmitter<Card> = new EventEmitter<Card>();

  title: string;
  distance: string;
  price: number;
  description: string;
  images: string[];

  constructor(public dialog: MatDialog, public storeService: StoreService) {}
  ngOnInit(): void {
    console.log(this.card.images);
    this.title = this.card.productName;
    this.price = this.card.cost;
    this.description = this.card.description;
    this.distance = this.card.distance;
    this.images = this.card.images;
    if (this.images.length === 0) {
      this.images = new Array<string>('../../assets/CardImages/NoImage.png');
    }
  }

  addToCart()
  {
    var result = this.storeService.AddToCart(this.card.productId);
    this.Added.emit(this.card);
  }

  // ../../assets/Images/rollerBlades.jpg
}
