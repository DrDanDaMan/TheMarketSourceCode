import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Card } from 'src/Models/cardModel';
import { DistanceService } from '../services/distance.service';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.css']
})

export class CartItemComponent implements OnInit {
  // slides = [{'image': '../../assets/Images/rollerBlades.jpg'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'},
  // {'image': 'https://gsr.dev/material2-carousel/assets/demo.png'}];

  temps: string[];

  @Input() card: Card;
  @Output() Removed: EventEmitter<Card> = new EventEmitter<Card>();

  title: string;
  distance: string;
  price: number;
  description: string;
  images: string[];

  constructor(public storeService: StoreService) {}
  ngOnInit(): void {
    console.log(this.card);
    this.title = this.card.productName;
    this.price = this.card.cost;
    this.description = this.card.description;
    this.distance = this.card.distance;
    this.images = this.card.images;
    if (this.images.length === 0) {
      this.images = new Array<string>('../../assets/CardImages/NoImage.png');
    }
  }

  removeCard()
  {
    console.log(this.card);
    this.Removed.emit(this.card);
    var result = this.storeService.RemoveFromCart(this.card.productId);
  }

  purchaseCard()
  {
    var result = this.storeService.PurchaseItem(this.card.productId);
    this.Removed.emit(this.card);
  }

  removeCardSpecial()
  {
    this.Removed.emit(this.card);
  }
  // ../../assets/Images/rollerBlades.jpg
}


