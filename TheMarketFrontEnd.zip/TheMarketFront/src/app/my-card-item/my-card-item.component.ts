import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Card } from 'src/Models/cardModel';
import { DistanceService } from '../services/distance.service';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-my-card-item',
  templateUrl: './my-card-item.component.html',
  styleUrls: ['./my-card-item.component.css']
})
export class MyCardItemComponent implements OnInit {

  temps: string[];

  @Input() card: Card;
  @Output() Deleted: EventEmitter<Card> = new EventEmitter<Card>();

  title: string;
  distance: string;
  price: number;
  description: string;
  images: string[];

  constructor(public storeService: StoreService) {}
  ngOnInit(): void {
    console.log(this.card);
    this.title = this.card.productName;
    this.price = this.card.cost;
    this.description = this.card.description;
    this.distance = this.card.distance;
    this.images = this.card.images;
    if (this.images.length === 0) {
      this.images = new Array<string>('../../assets/CardImages/NoImage.png');
    }
  }

  deleteCard()
  {
    console.log(this.card);
    this.Deleted.emit(this.card);
    var result = this.storeService.DeleteCard(this.card.productId);
  }

  // ../../assets/Images/rollerBlades.jpg
}
