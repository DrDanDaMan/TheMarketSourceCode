import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCardItemComponent } from './my-card-item.component';

describe('MyCardItemComponent', () => {
  let component: MyCardItemComponent;
  let fixture: ComponentFixture<MyCardItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyCardItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCardItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
