import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MaterialModule} from './MaterialModule';
// used to create fake backend
import { fakeBackendProvider } from './_helpers';
import { AppRoutingModule } from './app-routing.module';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AppComponent } from './app.component';
import { AlertComponent } from './_components';
import { HomeComponent } from './home';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CardComponent } from './card/card.component';
import { StoreFrontComponent } from './store-front/store-front.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { MatCarouselModule } from '@ngbmodule/material-carousel';
import { AddCardPageComponent } from './add-card-page/add-card-page.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CartComponent } from './cart/cart.component'
import { MessengerComponent } from './messenger/messenger.component';
import { CartItemComponent } from './cart-item/cart-item.component';
import { FilterBarComponent } from './filter-bar/filter-bar.component';
import { MyCardsComponent } from './my-cards/my-cards.component';
import { MyCardItemComponent } from './my-card-item/my-card-item.component';
import { RecommendedCardsComponent } from './recommended-cards/recommended-cards.component';
import { SuggestedCardsComponent } from './suggested-cards/suggested-cards.component';

@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        AppRoutingModule,
        MaterialModule,
        BrowserAnimationsModule,
        FormsModule,
        MatCarouselModule.forRoot(),
        FlexLayoutModule
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        CardComponent,
        StoreFrontComponent,
        AboutUsComponent,
        AddCardPageComponent,
        CartComponent ,
        MessengerComponent ,
        CartItemComponent,
        FilterBarComponent,
        MyCardsComponent,
        MyCardItemComponent,
        RecommendedCardsComponent,
        SuggestedCardsComponent  ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
