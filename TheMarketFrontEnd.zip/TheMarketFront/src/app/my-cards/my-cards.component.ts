import { Component, OnInit } from '@angular/core';
import { Card } from 'src/Models/cardModel';
import { StoreService } from '../services/store.service';

@Component({
  selector: 'app-my-cards',
  templateUrl: './my-cards.component.html',
  styleUrls: ['./my-cards.component.css']
})
export class MyCardsComponent implements OnInit {
  cards: Array<Card>;
  constructor(public storeService: StoreService) { }

  ngOnInit(): void {
    this.storeService.GetMyCards()
    .pipe().subscribe(arg => this.cards = arg);
    console.log("hit");
    console.log(this.cards);
    console.log("hit");
  }

  DeleteCard(card: Card)
  {
    console.log(card);
    const index: number = this.cards.indexOf(card);
    if (index !== -1) {
      this.cards.splice(index, 1);
    }
    console.log("Card Removed");
  }
}
