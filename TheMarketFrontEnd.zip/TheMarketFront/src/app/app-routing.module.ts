import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardComponent } from './card/card.component';
import { AddCardPageComponent } from './add-card-page/add-card-page.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home';
import { AuthGuard } from './_helpers';
import { StoreFrontComponent } from './store-front/store-front.component';
import { MyCardsComponent } from './my-cards/my-cards.component';

const accountModule = () => import('./account/account.module').then(x => x.AccountModule);
const usersModule = () => import('./users/users.module').then(x => x.UsersModule);

const routes: Routes = [
    { path: 'account', loadChildren: accountModule  },
    { path: 'myCards', component: MyCardsComponent},
    { path: 'addCard', component: AddCardPageComponent, canActivate: [AuthGuard] },
    { path: 'cart', component: CartComponent, canActivate: [AuthGuard] },
    { path: 'store', component: StoreFrontComponent, canActivate: [AuthGuard] },
    { path: '**', redirectTo: 'account/login' },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
