import { Component, OnInit } from '@angular/core';
import { Card } from 'src/Models/cardModel';
import { StoreService } from '../services/store.service';
import { User } from '../_models';

@Component({
  selector: 'app-recommended-cards',
  templateUrl: './recommended-cards.component.html',
  styleUrls: ['./recommended-cards.component.css']
})
export class RecommendedCardsComponent implements OnInit {
  sampleCard = new Card();
  constructor(public storeService: StoreService) { }
  products: Card[];
  user: User;
  searchString = '';

  ngOnInit(): void {
    this.sampleCard.productName = 'Roller Blades';
    this.sampleCard.cost = 12;
    this.sampleCard.distance = '8';
    this.sampleCard.description = 'GUC my son only wore once\ncomes with replacement wheels';
    this.user = JSON.parse(localStorage.getItem('user'));
    this.storeService.getAllRecommendedCards().pipe().subscribe(products => {this.products = products; console.log(this.products); });
  }

  search()
  {
    console.log(this.searchString);
    this.storeService.getFilteredCards(this.searchString).pipe().subscribe(products => {this.products = products; console.log(this.products); });
  }

  RemoveCard(card: Card)
  {
    const index: number = this.products.indexOf(card);
    if (index !== -1) {
      this.products.splice(index, 1);
    }
    console.log("Card Removed");
  }

}
