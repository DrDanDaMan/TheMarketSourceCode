﻿import { Interest } from 'src/Models/interestsModel';

export class User {
    userId: string;
    username: string;
    createDate: string;
    password: string;
    firstName: string;
    lastName: string;
    email: string;
    middleName: string;
    address: string;
    city: string;
    state: string;
    zipcode: string;
    phoneNumber: string;
    interests: string;
    token: string;
    id: string;
    interestArray: Array<Interest>;
}
