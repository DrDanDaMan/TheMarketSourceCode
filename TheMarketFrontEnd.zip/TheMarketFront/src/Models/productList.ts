import { Card } from './cardModel';

export class ProductList {
  public Products: Card[];
  public ErrorCode: number;
  public Result: string;

}
