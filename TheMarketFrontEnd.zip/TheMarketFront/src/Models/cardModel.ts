export class Card {
  public productId: number;
  public categories: string;
  public productName: string;
  public userID: number;
  public cost: number;
  public description: string;
  public datePosted: string;
  public distance: string;
  public images: string[];
  public isAvailable: boolean;
}
