export class Interest {
  public title: string;
  public value: boolean;
}
