import { Interest } from './interestsModel';
export const INTERESTS: Interest[] = [
    {title: 'Electronics', value: false},
    {title: 'Sports', value: false},
    {title: 'Appliances', value: false},
    {title: 'Vehicles', value: false},
    {title: 'Home & Garden', value: false},
    {title: 'Clothing', value: false},
    {title: 'Entertainment', value: false},
    {title: 'Beauty & Health', value: false},
    {title: 'Outdoors', value: false},
    ];
