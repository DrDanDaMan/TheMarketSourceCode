export class Coordinates {
  lat: number;
  lon: number;
}
