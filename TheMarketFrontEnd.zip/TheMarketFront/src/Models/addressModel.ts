export class Address {
    address: string;
    city: string;
    state: string;
}
