export class User {
  UserId: number;
  UserName: string;
  CreateDate = Date.now();
  Password: string;
  Email: string;
  UserLevelTypeId: string;
  UserTypeId: number;
  FirstName: string;
  MiddleName: string;
  LastName: string;
  Active = true;
  LogoutTime = Date.now();
  MobileNumber: string;
  BuyFlagCount = 0;
  SellFlageCount = 0;
  Address: string;
  City: string;
  State: string;
  ZipCode: string;
}

